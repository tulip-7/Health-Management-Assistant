exports.handler = async function(event, context) {
  const { message, api_key } = JSON.parse(event.body);
  
  if (!api_key) {
    return {
      statusCode: 400,
      body: JSON.stringify({
        success: false,
        response: '请先配置API Key！'
      })
    };
  }
  
  try {
    const response = await fetch('https://open.bigmodel.cn/api/paas/v4/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${api_key}`
      },
      body: JSON.stringify({
        model: 'glm-4-flash',
        messages: [
          {
            role: 'system',
            content: '你是一位专业的健康管理助手，擅长为用户提供饮食建议、运动计划和健康提醒服务。请根据用户的问题，用自然、友好的语言回答。重要：回答中不要使用任何星号（*）符号，包括不要用**来加粗文字。'
          },
          {
            role: 'user',
            content: message
          }
        ],
        temperature: 0.7,
        max_tokens: 2048
      })
    });
    
    const data = await response.json();
    
    if (data.choices && data.choices[0] && data.choices[0].message) {
      return {
        statusCode: 200,
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Headers': 'Content-Type'
        },
        body: JSON.stringify({
          success: true,
          intent: 'AI智能回答',
          intent_id: 'ai_response',
          response: data.choices[0].message.content
        })
      };
    } else {
      return {
        statusCode: 500,
        body: JSON.stringify({
          success: false,
          response: 'API返回数据异常'
        })
      };
    }
  } catch (error) {
    console.error('API调用失败:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        response: '抱歉，服务暂时不可用，请稍后再试。'
      })
    };
  }
};
