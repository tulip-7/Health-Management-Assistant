# -*- coding: utf-8 -*-
import json
import os
from datetime import datetime

try:
    from zhipuai import ZhipuAI
    ZHIPUAI_AVAILABLE = True
except ImportError:
    ZHIPUAI_AVAILABLE = False

class HealthAgentAPI:
    def __init__(self):
        self.agent_config = self.load_config()
        self.intent_handlers = {
            "diet_suggestion": self.handle_diet_suggestion,
            "exercise_plan": self.handle_exercise_plan,
            "health_reminder": self.handle_health_reminder
        }
        self.api_key = None
        self.client = None
    
    def load_config(self):
        config_path = os.path.join(os.path.dirname(__file__), '../agent/config.json')
        with open(config_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    def load_knowledge_base(self, kb_name):
        kb_path = os.path.join(os.path.dirname(__file__), f'../knowledge_base/{kb_name}_knowledge.json')
        with open(kb_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    def load_workflow(self, workflow_name):
        workflow_path = os.path.join(os.path.dirname(__file__), f'../workflows/{workflow_name}.json')
        with open(workflow_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    def detect_intent(self, user_input):
        for intent in self.agent_config['intents']:
            for trigger in intent['triggers']:
                if trigger in user_input.lower():
                    return intent['intent_id'], intent['name']
        return None, None
    
    def call_zhipuai(self, user_input, context="", api_key=""):
        """调用智谱AI大模型生成回答"""
        if not ZHIPUAI_AVAILABLE:
            return None
        
        if not api_key:
            print("错误：未提供API Key")
            return None
        
        try:
            system_prompt = f"""
你是一位专业的健康管理助手，擅长为用户提供饮食建议、运动计划和健康提醒服务。

你的知识库包含：
{context}

请根据用户的问题，结合知识库信息，用自然、友好的语言回答用户。
重要：回答中不要使用任何星号（*）符号，包括不要用**来加粗文字。
如果问题与健康无关，你可以礼貌地告知用户你主要提供健康相关的帮助。
            """.strip()
            
            client = ZhipuAI(api_key=api_key)
            
            response = client.chat.completions.create(
                model="glm-4-flash",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_input}
                ],
                temperature=0.7,
                max_tokens=2048
            )
            
            return response.choices[0].message.content
        
        except Exception as e:
            print(f"智谱AI调用失败: {e}")
            return None
    
    def call_zhipuai_image(self, user_input, image_base64, api_key=""):
        """调用智谱AI多模态模型进行图片识别"""
        try:
            import requests
            
            if not api_key:
                print("错误：未提供API Key")
                return None
            
            key = api_key
            
            if image_base64 and not image_base64.startswith('data:image'):
                image_base64 = 'data:image/png;base64,' + image_base64
            
            print(f"DEBUG - 调用图片识别: user_input={user_input[:50]}..., image_size={len(image_base64) if image_base64 else 0} bytes")
            
            system_prompt = """
你是一位专业的健康管理助手，擅长通过图片识别为用户提供健康相关的分析和建议。

重要识别规则：
1. 如果图片中是发芽的土豆（有绿色嫩芽、芽眼），必须提醒用户：发芽土豆含有龙葵素，有毒，绝对不能食用！
2. 如果图片中是发霉的食物，必须提醒用户：发霉食物含有黄曲霉素等有害物质，绝对不能食用！
3. 如果图片中是过期药品，必须提醒用户：过期药品可能失效或产生有害物质，绝对不能使用！

请仔细分析用户上传的图片，结合用户的问题，提供专业、准确的健康分析和建议。

分析内容包括：
1. 图片中的物体/场景识别
2. 与健康的关联分析
3. 相关的健康建议
4. 注意事项

重要：回答中不要使用任何星号（*）符号，包括不要用**来加粗文字。
回答风格要自然、友好、专业。
            """.strip()
            
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {key}"
            }
            
            payload = {
                "model": "glm-4v",
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": [
                        {"type": "text", "text": user_input},
                        {"type": "image_url", "image_url": {"url": image_base64}}
                    ]}
                ],
                "temperature": 0.7,
                "max_tokens": 2048
            }
            
            print(f"DEBUG - 发送请求到智谱AI...")
            response = requests.post(
                "https://open.bigmodel.cn/api/paas/v4/chat/completions",
                headers=headers,
                json=payload,
                timeout=60
            )
            
            print(f"DEBUG - 响应状态码: {response.status_code}")
            
            if response.status_code == 200:
                result = response.json()
                print(f"DEBUG - 响应内容: {result}")
                return result["choices"][0]["message"]["content"]
            else:
                print(f"智谱AI图片识别调用失败，状态码: {response.status_code}, 错误: {response.text}")
                return None
        
        except Exception as e:
            print(f"智谱AI图片识别调用失败: {e}")
            return None
    
    def format_diet_plan(self, plan_name, plan):
        response = f"🍽️ {plan_name}\n\n"
        response += f"🌅 早餐：{plan['breakfast']}\n"
        response += f"🌤️ 午餐：{plan['lunch']}\n"
        response += f"🌙 晚餐：{plan['dinner']}\n"
        response += f"🍎 加餐：{plan['snack']}\n\n"
        response += "💡 小贴士：记得细嚼慢咽，每餐七八分饱哦！"
        return response
    
    def format_food_recommendation(self, categories):
        response = "🥗 健康食物推荐\n\n"
        for category in categories:
            response += f"{category['name']}\n"
            for item in category['items'][:3]:
                response += f"  - {item['name']}: {item['benefits']}\n"
            response += "\n"
        return response
    
    def format_tips(self, tips):
        response = "💡 饮食小贴士\n\n"
        for i, tip in enumerate(tips, 1):
            response += f"{i}. {tip}\n"
        return response
    
    def handle_diet_suggestion(self, user_input, api_key=""):
        kb = self.load_knowledge_base('diet')
        
        if '减脂' in user_input or '减肥' in user_input:
            plan = kb['meal_plans']['减脂计划']
            return self.format_diet_plan('减脂计划', plan)
        elif '增肌' in user_input or '健身' in user_input:
            plan = kb['meal_plans']['增肌计划']
            return self.format_diet_plan('增肌计划', plan)
        elif '均衡' in user_input or '健康' in user_input:
            plan = kb['meal_plans']['均衡计划']
            return self.format_diet_plan('均衡饮食计划', plan)
        elif '食物' in user_input or '推荐' in user_input:
            return self.format_food_recommendation(kb['categories'])
        elif '饮食建议' in user_input:
            return self.format_tips(kb['diet_tips'])
        else:
            kb_context = f"""
饮食知识库：
餐单计划：{json.dumps(kb['meal_plans'], ensure_ascii=False)}
饮食小贴士：{json.dumps(kb['diet_tips'], ensure_ascii=False)}
            """.strip()
            ai_response = self.call_zhipuai(user_input, kb_context, api_key)
            return ai_response if ai_response else self.format_tips(kb['diet_tips'])
    
    def format_workout_plan(self, plan_name, plan):
        response = f"🏋️ {plan_name}\n\n"
        response += f"📅 训练频率：{plan['frequency']}\n\n"
        response += "📋 训练安排：\n"
        for day in plan['structure']:
            response += f"  - {day['day']}：{day['content']}\n"
        response += "\n💪 坚持就是胜利！"
        return response
    
    def format_flexibility_exercises(self, workout_types):
        for wt in workout_types:
            if wt['name'] == '柔韧性训练':
                response = "🧘 柔韧性训练推荐\n\n"
                for ex in wt['exercises']:
                    response += f"{ex['name']}\n"
                    if 'duration' in ex:
                        response += f"  - 时长：{ex['duration']}\n"
                    response += f"  - 益处：{ex['benefits']}\n\n"
                return response
        return "暂无相关训练推荐"
    
    def format_exercise_tips(self, tips):
        response = "💡 运动小贴士\n\n"
        for i, tip in enumerate(tips, 1):
            response += f"{i}. {tip}\n"
        return response
    
    def handle_exercise_plan(self, user_input, api_key=""):
        kb = self.load_knowledge_base('exercise')
        
        if '新手' in user_input or '初学' in user_input:
            plan = kb['workout_plans']['初学者计划']
            return self.format_workout_plan('初学者计划', plan)
        elif '减脂' in user_input or '减肥' in user_input:
            plan = kb['workout_plans']['减脂计划']
            return self.format_workout_plan('减脂计划', plan)
        elif '进阶' in user_input or '增肌' in user_input:
            plan = kb['workout_plans']['进阶计划']
            return self.format_workout_plan('进阶计划', plan)
        elif '瑜伽' in user_input or '拉伸' in user_input:
            return self.format_flexibility_exercises(kb['workout_types'])
        elif '运动计划' in user_input:
            return self.format_exercise_tips(kb['exercise_tips'])
        else:
            kb_context = f"""
运动知识库：
训练计划：{json.dumps(kb['workout_plans'], ensure_ascii=False)}
运动小贴士：{json.dumps(kb['exercise_tips'], ensure_ascii=False)}
            """.strip()
            ai_response = self.call_zhipuai(user_input, kb_context, api_key)
            return ai_response if ai_response else self.format_exercise_tips(kb['exercise_tips'])
    
    def set_reminder(self, reminder):
        response = f"🔔 提醒已设置\n\n"
        response += f"提醒名称：{reminder['name']}\n"
        response += f"提醒间隔：{reminder['interval']}\n"
        response += f"提醒内容：{reminder['message']}\n\n"
        response += "✅ 提醒设置成功！"
        return response
    
    def show_all_reminders(self, reminders):
        response = "📋 可用提醒列表\n\n"
        
        response += "🌞 晨间提醒：\n"
        for r in reminders['morning_reminders']:
            response += f"  - {r['name']} ({r['time']})\n"
        
        response += "\n⏰ 日间提醒：\n"
        for r in reminders['daily_reminders']:
            response += f"  - {r['name']} ({r['interval']})\n"
        
        response += "\n🌙 晚间提醒：\n"
        for r in reminders['evening_reminders']:
            response += f"  - {r['name']} ({r['time']})\n"
        
        return response
    
    def handle_health_reminder(self, user_input, api_key=""):
        kb = self.load_knowledge_base('health')
        
        if '喝水' in user_input or '饮水' in user_input:
            reminder = kb['reminders']['daily_reminders'][0]
            return self.set_reminder(reminder)
        elif '休息' in user_input or '活动' in user_input:
            reminder = kb['reminders']['daily_reminders'][1]
            return self.set_reminder(reminder)
        elif '护眼' in user_input or '眼睛' in user_input:
            reminder = kb['reminders']['daily_reminders'][2]
            return self.set_reminder(reminder)
        elif '服药' in user_input:
            return "💊 好的，我可以帮您设置服药提醒。请问您需要在什么时间服药呢？"
        elif '睡眠' in user_input:
            reminder = kb['reminders']['evening_reminders'][1]
            return self.set_reminder(reminder)
        elif '健康提醒' in user_input:
            return self.show_all_reminders(kb['reminders'])
        else:
            kb_context = f"""
健康知识库：
提醒设置：{json.dumps(kb['reminders'], ensure_ascii=False)}
健康建议：{json.dumps(kb['health_advice'], ensure_ascii=False)}
            """.strip()
            ai_response = self.call_zhipuai(user_input, kb_context, api_key)
            return ai_response if ai_response else self.show_all_reminders(kb['reminders'])
    
    def process_message(self, user_input, api_key="", image_base64=None):
        print(f"DEBUG - 用户输入: {repr(user_input)}")
        print(f"DEBUG - 图片数据: {'已提供' if image_base64 else '未提供'}")
        
        if image_base64:
            ai_response = self.call_zhipuai_image(user_input, image_base64, api_key)
            if ai_response:
                response = ai_response
            else:
                response = "🖼️ 图片识别失败\n\n抱歉，图片识别服务暂时不可用。请检查您的网络连接或稍后再试。\n\n💡 提示：确保上传的图片清晰，支持JPG、PNG格式。"
            
            return {
                "success": True,
                "intent": "图片识别",
                "intent_id": "image_recognition",
                "response": response,
                "timestamp": datetime.now().isoformat()
            }
        
        intent_id, intent_name = self.detect_intent(user_input)
        print(f"DEBUG - 识别意图: intent_id={intent_id}, intent_name={intent_name}")
        
        if intent_id and intent_id in self.intent_handlers:
            response = self.intent_handlers[intent_id](user_input, api_key)
            return {
                "success": True,
                "intent": intent_name,
                "intent_id": intent_id,
                "response": response,
                "timestamp": datetime.now().isoformat()
            }
        else:
            ai_response = self.call_zhipuai(user_input, "你是一位专业的健康管理助手，可以回答各种健康相关问题。重要：回答中不要使用任何星号（*）符号，包括不要用**来加粗文字。", api_key)
            if ai_response:
                response = ai_response
            else:
                response = f"您好！我是您的健康管理助手。请问您需要哪方面的帮助呢？\n\n🎯 我可以帮您：\n- 🍽️ 饮食建议\n- 🏋️ 运动计划\n- 🔔 健康提醒"
            
            return {
                "success": True,
                "intent": "通用对话",
                "intent_id": "general",
                "response": response,
                "timestamp": datetime.now().isoformat()
            }

if __name__ == "__main__":
    agent = HealthAgentAPI()
    
    print("🏥 健康管理助手已启动（集成智谱AI）")
    print("------------------------")
    
    while True:
        user_input = input("您：")
        if user_input.lower() in ['退出', 'quit', 'exit']:
            print("👋 再见！祝您身体健康！")
            break
        
        response = agent.process_message(user_input)
        print(f"\n🤖 [{response['intent']}]\n{response['response']}\n")
        print("------------------------")