from flask import Flask, request, jsonify, render_template
from agent_api import HealthAgentAPI

app = Flask(__name__)
agent = HealthAgentAPI()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/chat', methods=['POST'])
def chat():
    user_input = request.json.get('message', "")
    response = agent.process_message(user_input)
    return jsonify(response)

@app.route('/api/intents', methods=['GET'])
def get_intents():
    intents = []
    for intent in agent.agent_config['intents']:
        intents.append({
            "id": intent['intent_id'],
            "name": intent['name'],
            "description": intent.get('description', "")
        })
    return jsonify(intents)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)