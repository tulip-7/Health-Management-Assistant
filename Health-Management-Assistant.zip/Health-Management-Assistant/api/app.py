# -*- coding: utf-8 -*-
from flask import Flask, request, jsonify, render_template
from agent_api import HealthAgentAPI

app = Flask(__name__)
app.config['JSON_AS_ASCII'] = False
agent = HealthAgentAPI()

@app.after_request
def after_request(response):
    response.headers.add('Access-Control-Allow-Origin', '*')
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
    response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE')
    return response

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/chat', methods=['POST'])
def chat():
    print(f"\n=== 收到新请求 ===")
    print(f"DEBUG - 请求数据长度: {len(request.data.decode('utf-8'))} bytes")
    print(f"DEBUG - 请求JSON: {request.json}")
    user_input = request.json.get('message', "")
    api_key = request.json.get('api_key', "")
    image_base64 = request.json.get('image', None)
    print(f"DEBUG - 用户输入: {repr(user_input)}")
    print(f"DEBUG - API Key: {'已提供' if api_key else '未提供'}")
    print(f"DEBUG - 图片数据: {'已提供' if image_base64 else '未提供'}, 长度: {len(image_base64) if image_base64 else 0}")
    response = agent.process_message(user_input, api_key, image_base64)
    print(f"DEBUG - 响应: {response}")
    return jsonify(response)

@app.route('/api/intents', methods=['GET'])
def get_intents():
    intents = []
    for intent in agent.agent_config['intents']:
        intents.append({
            "id": intent['intent_id'],
            "name": intent['name'],
            "description": intent.get('description', "")
        })
    return jsonify(intents)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)