import sys
sys.path.append("d:\\largemodel")

from src.config import Config
from src.llm import get_glm4_llm
from src.rag import get_rag_system
from src.agents import get_travel_agent

print("=== 测试AI旅游规划Agent系统 ===")
print()

print("1. 测试配置加载...")
try:
    Config.validate()
    print(f"   ✓ 配置验证通过")
    print(f"   - API Key: {Config.ZHIPU_API_KEY[:10]}...")
    print(f"   - 模型: {Config.MODEL_NAME}")
except Exception as e:
    print(f"   ✗ 配置验证失败: {e}")

print()
print("2. 测试RAG知识库...")
try:
    rag = get_rag_system()
    doc_count = rag.build_knowledge_base()
    print(f"   ✓ 知识库初始化成功，共 {doc_count} 个城市")
    cities = list(rag.get_knowledge_cache().keys())
    print(f"   - 包含城市: {', '.join(cities)}")
except Exception as e:
    print(f"   ✗ 知识库初始化失败: {e}")

print()
print("3. 测试GLM-4模型...")
try:
    llm = get_glm4_llm()
    response = llm._call("你好，请介绍一下你自己")
    print(f"   ✓ 模型调用成功")
    print(f"   - 响应: {response[:50]}...")
except Exception as e:
    print(f"   ✗ 模型调用失败: {e}")

print()
print("4. 测试旅游Agent...")
try:
    agent = get_travel_agent()
    response = agent.run("北京有什么好玩的景点？")
    print(f"   ✓ Agent调用成功")
    print(f"   - 响应: {response[:100]}...")
except Exception as e:
    print(f"   ✗ Agent调用失败: {e}")

print()
print("=== 测试完成 ===")