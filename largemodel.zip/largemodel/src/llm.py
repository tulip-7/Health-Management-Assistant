from langchain.llms.base import LLM
from typing import Optional, List, Mapping, Any, Iterator
from zhipuai import ZhipuAI
from config import Config
import time

class GLM4LLM(LLM):
    client: ZhipuAI = None
    model_name: str = Config.MODEL_NAME
    
    def __init__(self):
        super().__init__()
        self.client = ZhipuAI(api_key=Config.ZHIPU_API_KEY)
    
    @property
    def _llm_type(self) -> str:
        return "glm-4-flash"
    
    def _call(self, prompt: str, stop: Optional[List[str]] = None) -> str:
        response = self.client.chat.completions.create(
            model=self.model_name,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.7,
            max_tokens=2048
        )
        return response.choices[0].message.content
    
    def stream(self, prompt: str) -> Iterator[str]:
        response = self.client.chat.completions.create(
            model=self.model_name,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.7,
            max_tokens=2048,
            stream=True
        )
        for chunk in response:
            if chunk.choices[0].delta.content:
                yield chunk.choices[0].delta.content
    
    @property
    def _identifying_params(self) -> Mapping[str, Any]:
        return {"model_name": self.model_name}

def get_glm4_llm() -> GLM4LLM:
    return GLM4LLM()