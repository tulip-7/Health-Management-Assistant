from llm import get_glm4_llm
from rag import RAGSystem
from memory import TravelMemory

class MultiAgentTravelPlanner:
    def __init__(self):
        self.llm = get_glm4_llm()
        self.rag_system = RAGSystem()
        self.memory = TravelMemory()
        
        self.system_prompt = """
你是一个专业的AI旅游规划师，擅长为用户制定详细的旅行计划。

你拥有以下知识库信息：
{knowledge}

请根据用户的需求，提供专业、详细的旅游建议和行程规划。
"""
    
    def plan_trip(self, user_request: str) -> str:
        knowledge = self._get_relevant_knowledge(user_request)
        prompt = self.system_prompt.format(knowledge=knowledge)
        full_prompt = f"{prompt}\n\n用户需求：{user_request}\n\n请提供详细的旅游规划建议。"
        
        self.memory.add_message("user", user_request)
        response = self.llm._call(full_prompt)
        self.memory.add_message("assistant", response)
        
        return response
    
    def _get_relevant_knowledge(self, query: str) -> str:
        results = self.rag_system.query_knowledge(query)
        if results:
            return "\n\n".join([doc.page_content for doc in results])
        return "暂无知识库信息"
    
    def get_conversation_history(self):
        return self.memory.get_history()
    
    def clear_history(self):
        self.memory.clear_memory()

def get_multi_agent_planner() -> MultiAgentTravelPlanner:
    return MultiAgentTravelPlanner()