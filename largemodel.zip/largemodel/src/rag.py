from config import Config
import os

class RAGSystem:
    def __init__(self):
        self.knowledge_base = {}
        self._create_default_travel_data()
        self._load_knowledge_base()
    
    def _load_knowledge_base(self):
        if os.path.exists(Config.DATA_PATH):
            for filename in os.listdir(Config.DATA_PATH):
                if filename.endswith('.txt'):
                    filepath = os.path.join(Config.DATA_PATH, filename)
                    with open(filepath, 'r', encoding='utf-8') as f:
                        city_name = filename.replace('.txt', '')
                        self.knowledge_base[city_name] = f.read()
    
    def _create_default_travel_data(self):
        if not os.path.exists(Config.DATA_PATH):
            os.makedirs(Config.DATA_PATH, exist_ok=True)
        
        default_data = {
            "beijing": """北京是中国的首都，拥有丰富的历史文化遗产。
主要景点：故宫、天安门广场、颐和园、八达岭长城、天坛、鸟巢
最佳旅游季节：秋季（9-10月），气候宜人
特色美食：北京烤鸭、炸酱面、豆汁儿、卤煮火烧
建议游玩天数：3-5天""",
            "shanghai": """上海是中国最大的城市，现代化与传统文化交融。
主要景点：外滩、东方明珠塔、豫园、南京路步行街、迪士尼乐园
最佳旅游季节：春季（3-5月）和秋季（9-11月）
特色美食：小笼包、生煎包、本帮菜
建议游玩天数：3-4天""",
            "hangzhou": """杭州是著名的风景旅游城市，以西湖闻名。
主要景点：西湖、灵隐寺、雷峰塔、千岛湖、西溪湿地
最佳旅游季节：春季（3-4月樱花季）和秋季（10-11月桂花季）
特色美食：西湖醋鱼、龙井虾仁、叫化鸡
建议游玩天数：2-3天""",
            "chengdu": """成都是四川省会，以美食和悠闲生活闻名。
主要景点：大熊猫基地、宽窄巷子、锦里、都江堰、青城山
最佳旅游季节：春秋两季，避开夏季炎热
特色美食：火锅、串串香、担担面、夫妻肺片
建议游玩天数：3-4天""",
            "sanya": """三亚是中国最南端的热带海滨城市。
主要景点：亚龙湾、天涯海角、蜈支洲岛、三亚湾、南山文化旅游区
最佳旅游季节：冬季（11月-次年3月）避寒胜地
特色美食：海鲜、椰子鸡、抱罗粉
建议游玩天数：4-5天"""
        }
        
        for city_name, content in default_data.items():
            filepath = os.path.join(Config.DATA_PATH, f"{city_name}.txt")
            if not os.path.exists(filepath):
                with open(filepath, 'w', encoding='utf-8') as f:
                    f.write(content)
    
    def build_knowledge_base(self):
        self._create_default_travel_data()
        self._load_knowledge_base()
        return len(self.knowledge_base)
    
    def query_knowledge(self, query, k=4):
        results = []
        query_lower = query.lower()
        
        for city, content in self.knowledge_base.items():
            if city in query_lower or query_lower in city:
                results.append(type('obj', (object,), {'page_content': content}))
        
        return results[:k]
    
    def get_knowledge_cache(self):
        return self.knowledge_base
    
    def clear_knowledge_base(self):
        self.knowledge_base = {}

def get_rag_system() -> RAGSystem:
    return RAGSystem()