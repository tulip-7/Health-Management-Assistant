from langchain.chains import LLMChain
from langchain.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain.memory import ConversationBufferMemory
from llm import get_glm4_llm
from tools import get_all_tools, call_tool
from memory import TravelMemory
from typing import Optional

class TravelPlanningAgent:
    def __init__(self):
        self.llm = get_glm4_llm()
        self.tools = get_all_tools()
        self.memory = TravelMemory()
        self.chain = self._create_chain()
    
    def _create_chain(self):
        system_prompt = """
你是一个专业的AI旅游规划师，你的任务是帮助用户规划完美的旅行。

可用工具：
1. get_weather(city) - 获取指定城市的天气信息
2. search_flights(from_city, to_city, date) - 搜索航班信息
3. search_hotels(city, check_in, check_out) - 搜索酒店信息
4. search_travel_knowledge(query) - 搜索旅游知识库
5. get_attraction_recommendations(city) - 获取景点推荐

请直接回答用户问题，使用你的专业知识和工具来提供帮助。
如果需要调用工具，请在回答中包含工具调用结果。

请用友好、专业的语言与用户交流。
"""

        prompt = ChatPromptTemplate.from_messages([
            ("system", system_prompt),
            MessagesPlaceholder(variable_name="history"),
            ("user", "{input}"),
        ])
        
        memory = ConversationBufferMemory(memory_key="history", return_messages=True)
        return LLMChain(llm=self.llm, prompt=prompt, memory=memory)
    
    def _call_tool(self, tool_name: str, **kwargs):
        for tool in self.tools:
            if tool.name == tool_name:
                return tool.run(**kwargs)
        return f"未找到工具: {tool_name}"
    
    def run(self, user_input: str) -> str:
        self.memory.add_message("user", user_input)
        
        tool_results = []
        for tool in self.tools:
            if tool.name == "search_travel_knowledge":
                result = call_tool("search_travel_knowledge", query=user_input)
                if result and "未找到" not in result:
                    tool_results.append(f"【旅游知识库】\n{result}")
            elif tool.name == "get_attraction_recommendations":
                result = call_tool("get_attraction_recommendations", city=user_input)
                if result and "未找到" not in result:
                    tool_results.append(f"【景点推荐】\n{result}")
        
        context = "\n\n".join(tool_results)
        if context:
            user_input_with_context = f"用户需求: {user_input}\n\n参考信息:\n{context}"
        else:
            user_input_with_context = user_input
        
        result = self.chain.run(input=user_input_with_context)
        self.memory.add_message("assistant", result)
        return result
    
    def get_memory(self):
        return self.memory
    
    def clear_history(self):
        self.memory.clear_memory()

class DestinationResearcherAgent:
    def __init__(self):
        self.llm = get_glm4_llm()
        self.tools = get_all_tools()
    
    def research_destination(self, destination: str) -> str:
        knowledge = call_tool("search_travel_knowledge", query=destination)
        
        prompt = f"""
请帮我研究以下旅游目的地的详细信息：
目的地：{destination}

参考资料：
{knowledge}

请提供：
1. 主要景点推荐
2. 最佳旅游季节
3. 特色美食
4. 文化特色
5. 旅行注意事项
"""
        return self.llm._call(prompt)

class ItineraryPlannerAgent:
    def __init__(self):
        self.llm = get_glm4_llm()
    
    def plan_itinerary(self, destination: str, days: int, preferences: dict) -> str:
        prompt = f"""
请帮我制定一份详细的旅行行程计划：
目的地：{destination}
旅行天数：{days}天
偏好：{preferences}

请按照以下格式输出：
第1天：
- 上午：活动安排
- 下午：活动安排
- 晚上：活动安排
- 餐饮推荐

第2天：
...

请包含景点介绍、交通方式、预计费用等信息。
"""
        return self.llm._call(prompt)

def get_travel_agent() -> TravelPlanningAgent:
    return TravelPlanningAgent()

def get_researcher_agent() -> DestinationResearcherAgent:
    return DestinationResearcherAgent()

def get_planner_agent() -> ItineraryPlannerAgent:
    return ItineraryPlannerAgent()