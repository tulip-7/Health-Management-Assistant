class VectorDB:
    def __init__(self):
        pass
    
    def add_documents(self, documents):
        pass
    
    def similarity_search(self, query, k=4):
        return []
    
    def clear(self):
        pass
    
    def get_collection(self):
        return None

def get_vector_db() -> VectorDB:
    return VectorDB()