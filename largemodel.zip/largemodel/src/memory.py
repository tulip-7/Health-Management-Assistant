from typing import Optional
from langchain.memory import ConversationBufferMemory, ConversationSummaryMemory
from langchain.chains import ConversationChain
from llm import get_glm4_llm

class TravelMemory:
    def __init__(self):
        self.buffer_memory = ConversationBufferMemory(
            memory_key="history",
            return_messages=True
        )
        self.summary_memory = ConversationSummaryMemory(
            llm=get_glm4_llm(),
            memory_key="summary",
            return_messages=True
        )
        self.travel_plans = {}
    
    def add_message(self, role: str, content: str):
        self.buffer_memory.chat_memory.add_user_message(content) if role == "user" else \
            self.buffer_memory.chat_memory.add_ai_message(content)
    
    def get_history(self):
        return self.buffer_memory.load_memory_variables({})
    
    def get_summary(self):
        return self.summary_memory.load_memory_variables({})
    
    def save_travel_plan(self, plan_id: str, plan_data: dict):
        self.travel_plans[plan_id] = plan_data
    
    def get_travel_plan(self, plan_id: str) -> Optional[dict]:
        return self.travel_plans.get(plan_id)
    
    def clear_memory(self):
        self.buffer_memory.clear()
        self.summary_memory.clear()
        self.travel_plans = {}

def get_travel_memory() -> TravelMemory:
    return TravelMemory()