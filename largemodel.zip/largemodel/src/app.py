import streamlit as st
import sys
import os

current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(current_dir)

from multi_agent import MultiAgentTravelPlanner
from rag import RAGSystem
from config import Config

def main():
    st.set_page_config(page_title="AI旅游规划Agent系统", page_icon="✈️", layout="wide")
    
    st.title("✈️ AI旅游规划Agent系统")
    
    if 'agent' not in st.session_state:
        st.session_state.agent = MultiAgentTravelPlanner()
        st.session_state.rag_initialized = False
    
    if not st.session_state.rag_initialized:
        rag = RAGSystem()
        rag.build_knowledge_base()
        st.session_state.rag_initialized = True
    
    if 'messages' not in st.session_state:
        st.session_state.messages = [
            {"role": "assistant", "content": "您好！我是您的AI旅游规划助手。请问您想去哪里旅行？"}
        ]
    
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])
    
    if user_input := st.chat_input("请输入您的旅行需求..."):
        st.session_state.messages.append({"role": "user", "content": user_input})
        with st.chat_message("user"):
            st.markdown(user_input)
        
        with st.chat_message("assistant"):
            try:
                response = st.session_state.agent.plan_trip(user_input)
                st.markdown(response)
                st.session_state.messages.append({"role": "assistant", "content": response})
            except Exception as e:
                st.error(f"处理请求时发生错误：{str(e)}")
    
    with st.sidebar:
        st.header("功能面板")
        
        if st.button("🔄 清除对话历史"):
            st.session_state.agent.clear_history()
            st.session_state.messages = [
                {"role": "assistant", "content": "您好！我是您的AI旅游规划助手。请问您想去哪里旅行？"}
            ]
            st.experimental_rerun()
        
        st.divider()
        
        st.subheader("快速开始")
        quick_options = [
            "帮我规划3天北京之旅",
            "上海有什么好玩的景点？",
            "推荐一个适合周末度假的地方",
            "三亚5天自由行攻略"
        ]
        
        for option in quick_options:
            if st.button(option):
                st.session_state.messages.append({"role": "user", "content": option})
                with st.chat_message("user"):
                    st.markdown(option)
                
                with st.chat_message("assistant"):
                    try:
                        response = st.session_state.agent.plan_trip(option)
                        st.markdown(response)
                        st.session_state.messages.append({"role": "assistant", "content": response})
                    except Exception as e:
                        st.error(f"处理请求时发生错误：{str(e)}")

if __name__ == "__main__":
    main()