import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    ZHIPU_API_KEY = os.getenv("ZHIPU_API_KEY")
    CHROMA_DB_PATH = os.getenv("CHROMA_DB_PATH", "./chroma_db")
    DATA_PATH = os.getenv("DATA_PATH", "./data")
    MODEL_NAME = "glm-4-flash"
    EMBEDDING_MODEL = "all-MiniLM-L6-v2"
    
    @staticmethod
    def validate():
        if not Config.ZHIPU_API_KEY:
            raise ValueError("ZHIPU_API_KEY is not set in environment variables")
        return True