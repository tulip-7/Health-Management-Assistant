from typing import Optional
from langchain.tools import BaseTool
from langchain.tools import StructuredTool
from rag import RAGSystem
from datetime import datetime

class WeatherTool(BaseTool):
    name = "get_weather"
    description = "获取指定城市的天气信息"
    
    def _run(self, city: str) -> str:
        return f"{city}的天气信息：晴朗，温度25-32°C，适合旅游。"

class FlightSearchTool(BaseTool):
    name = "search_flights"
    description = "搜索航班信息，参数包括出发城市、到达城市和日期"
    
    def _run(self, from_city: str, to_city: str, date: str = None) -> str:
        if date is None:
            date = datetime.now().strftime("%Y-%m-%d")
        return f"从{from_city}到{to_city}在{date}的航班信息：\n- 航班CA1234：08:00起飞，10:30到达，价格680元\n- 航班MU5678：14:00起飞，16:45到达，价格550元"

class HotelSearchTool(BaseTool):
    name = "search_hotels"
    description = "搜索酒店信息，参数包括城市、入住日期和离店日期"
    
    def _run(self, city: str, check_in: str = None, check_out: str = None) -> str:
        if check_in is None:
            check_in = datetime.now().strftime("%Y-%m-%d")
        if check_out is None:
            check_out = datetime.now().strftime("%Y-%m-%d")
        return f"{city}的酒店推荐：\n- 五星酒店：香格里拉大酒店，价格1200元/晚\n- 四星酒店：如家精选酒店，价格450元/晚\n- 经济型酒店：7天连锁酒店，价格200元/晚"

class TravelKnowledgeTool(BaseTool):
    name = "search_travel_knowledge"
    description = "搜索旅游知识库，获取目的地信息、景点推荐、美食等"
    
    def _run(self, query: str) -> str:
        rag = RAGSystem()
        results = rag.query_knowledge(query)
        if results:
            return "\n\n".join([doc.page_content for doc in results])
        return "未找到相关旅游信息"

class AttractionRecommendationTool(BaseTool):
    name = "get_attraction_recommendations"
    description = "获取指定城市的景点推荐"
    
    def _run(self, city: str) -> str:
        rag = RAGSystem()
        results = rag.query_knowledge(city)
        if results:
            content = "\n\n".join([doc.page_content for doc in results])
            import re
            attractions = re.findall(r"主要景点：(.+?)(?=\n|$)", content)
            if attractions:
                return f"{city}的主要景点推荐：{attractions[0]}"
        return f"未找到{city}的景点信息"

def get_all_tools():
    return [
        WeatherTool(),
        FlightSearchTool(),
        HotelSearchTool(),
        TravelKnowledgeTool(),
        AttractionRecommendationTool()
    ]

def call_tool(tool_name: str, **kwargs):
    tools = get_all_tools()
    for tool in tools:
        if tool.name == tool_name:
            return tool.invoke(kwargs)
    return f"未找到工具: {tool_name}"